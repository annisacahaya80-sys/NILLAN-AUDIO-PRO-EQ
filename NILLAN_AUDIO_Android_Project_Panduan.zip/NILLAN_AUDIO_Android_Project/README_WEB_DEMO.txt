NILLAN AUDIO DIGITAL MIXER V2

Fitur: input mic, pilih file musik lokal, level terpisah mic/music, EQ 10-band, compressor, master output dan monitor.

Cara pakai:
1. Ekstrak ZIP di Oppo A54.
2. Buka index.html lewat browser. Izin mic bisa dibatasi pada file lokal; jika demikian, perlu hosting HTTPS.
3. Tekan AKTIFKAN MIKROFON dan izinkan akses mic.
4. Pilih file audio dari HP sebagai sumber musik. Audio lokal akan diproses melalui EQ bersama jalur mic.
5. Gunakan headset jika mengaktifkan monitor.

YouTube & TikTok:
- Tombol YouTube hanya membuka YouTube di tab/aplikasi terpisah. Halaman web ini tidak dapat mengambil audio dari aplikasi YouTube untuk diproses karena batasan keamanan/CORS dan proteksi konten.
- Android umumnya tidak membolehkan web app mengganti input mic TikTok dengan hasil mix. Audio hasil mixer ini hanya keluar ke output browser.
- Untuk TikTok Live, perlu routing eksternal yang sesuai (mixer/sound card dengan loopback/mix-minus) atau aplikasi native Android dengan akses routing yang tepat. V8/X50 tidak otomatis menjamin fungsi ini.
- Tidak merekam atau mengunggah audio.
