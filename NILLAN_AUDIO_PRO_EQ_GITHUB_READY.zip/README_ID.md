# NILLAN AUDIO PRO EQ — proyek Android

Paket ini adalah **kode sumber**, bukan APK siap pasang.

## Fitur yang disiapkan
- Graphic EQ 10/21 band
- 5 kontrol PEQ (frekuensi, gain, Q)
- Bass boost, gain, compressor, limiter, preset

## Catatan penting
Efek audio Android pada session 0 tidak dijamin memengaruhi audio Brave di semua ponsel. Harus diuji pada Oppo A54 setelah APK berhasil dibuat. PEQ di versi ini dipetakan ke band EQ Android; belum berupa filter biquad mandiri dengan Q bebas.

## Build melalui GitHub Actions
1. Buat repository GitHub baru atau gunakan repository yang sudah ada.
2. Unggah **isi folder proyek ini** ke root repository. Pastikan `app/`, `build.gradle`, `settings.gradle`, `gradle.properties`, dan `.github/workflows/build-apk.yml` terlihat di halaman utama repository. Jangan hanya mengunggah file ZIP.
3. Commit perubahan ke branch default (biasanya `main`).
4. Buka tab **Actions**. Pilih **Build NILLAN AUDIO PRO EQ APK**, lalu **Run workflow** jika tersedia.
5. Setelah sukses, buka hasil run dan unduh artifact `NILLAN-AUDIO-PRO-EQ-debug-apk`. Di dalamnya ada `app-debug.apk`.

Jika nama workflow tidak muncul di Actions, pastikan file `.github/workflows/build-apk.yml` sudah di-commit ke branch default dan folder/file proyek lain juga sudah di-commit.
